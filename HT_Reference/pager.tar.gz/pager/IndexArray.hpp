#ifndef _INDEX_ARRAY_HPP
#define _INDEX_ARRAY_HPP

//#include <iterator>
#include <assert.h>
// size_t is in stdlib.h
#include <type_traits>
#include <stdio.h>

template <typename vT, typename iT>
class IndexArray
{
public:

  typedef vT value_type;
  typedef iT index_type;
  typedef vT& value_reference;
  typedef iT& index_reference;
  typedef vT* value_pointer;
  typedef iT* index_pointer;
  typedef const vT& const_value_reference;
  


 
 

 
  IndexArray()  { }
  
  void setup(value_pointer refp, size_t elem_sz, index_pointer indexp, int len, value_pointer sp, int sp_len) 
  {
    ref_base = refp;
    ref_elem_size = elem_sz;
    idx_base = indexp;
    idx_len = len;
    scratchpad = sp;
    scratchpad_len = sp_len;
  }

  inline int ialen() { return idx_len;}

  value_type& operator[](size_t index)
  {
    assert(index < idx_len);
    return ref_base[idx_base[index]];

  }
 
  const value_type& operator[](size_t index) const
  {
    assert(index < idx_len);
    return ref_base[idx_base[index]];
  }

  inline bool insp() {
    return ((curr_idx >= spix) && (curr_idx < spix+scratchpad_len));
  }

  inline bool lastsp() {
    return ((curr_idx >= spix + scratchpad_len) || (curr_idx >= idx_len));
  }
  
  inline void fillsp() {

    index_type tmp_idx = spix = curr_idx; 
    for (size_t i = 0; i < scratchpad_len; i++) {
      if (tmp_idx >= idx_len) break;
      scratchpad[i] = ref_base[idx_base[tmp_idx++]];
    }
  }
    
  inline void drainsp() {
     
    for (size_t i = 0; i < scratchpad_len; i++) {
      ref_base[idx_base[spix++]] = scratchpad[i];
      if (spix >= idx_len) break;
    }
      
    
  }
    
  inline value_reference get() {


    if (!insp()) fillsp();
    //printf("val, curridx, sp %d, %d, %d\n", scratchpad[curr_idx-spix], curr_idx, spix);
    curr_idx++;
    return scratchpad[curr_idx-1-spix];
  }
    
  inline void put(value_reference v) {
    //printf("val, curridx, sp %d, %d, %d\n", v, curr_idx, spix);
    scratchpad[curr_idx-spix] = v;
    curr_idx++;
    if (lastsp()) drainsp();
  }

  void init_inloop() {
    curr_idx = 0;
    spix = 0;
    fillsp();
  }

  void init_outloop() {
    curr_idx = 0;
    spix = 0;
  }
  
  
private:
  value_pointer ref_base;  // reference array base address
  size_t ref_elem_size;  // reference element size
  index_pointer idx_base;  // index array base address
  int idx_len;      // size of index array
  int curr_idx, spix;
  value_pointer scratchpad;
  int scratchpad_len;
};
 
#endif
