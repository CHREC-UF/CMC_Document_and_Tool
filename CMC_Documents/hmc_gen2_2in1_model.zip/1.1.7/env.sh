#!/bin/bash

export BFM_ROOT=`pwd`

# Default from the readme.2in1.txt; change if necessary
export VG_GNU_PACKAGE=$BFM_ROOT/sysc/vcs-compiler/amd64
